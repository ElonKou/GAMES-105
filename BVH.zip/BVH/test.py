from bvh_utils import *


def main():
    # one frame mocap data 
    bvh = BVHMotion('music_dance.bvh')
    # bvh.adjust_joint_name(name_list)
    translations, orientations = bvh.batch_forward_kinematics()
    T_pose = bvh.get_T_pose()
    print(translations.shape)
  
if __name__ == '__main__':
    main()